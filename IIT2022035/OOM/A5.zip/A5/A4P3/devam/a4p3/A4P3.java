/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package devam.a4p3;
import Classes.*;
/**
 *
 * @author devam
 */
public class A4P3 {

    public static void main(String[] args) {
        Animal a1 = new Lion("Simba",5);
        Animal a2=new Dolphin("Rishi",19);
        a1.speak();
        a2.speak();
    }
}
