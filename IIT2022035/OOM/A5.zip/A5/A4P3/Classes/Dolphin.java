/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author devam
 */
public class Dolphin extends Animal {
    public void speak(){
        System.out.println("Ee-EEE!!\n");
    }
    public Dolphin(String name,int age){
        super(name,age);
    }
}
