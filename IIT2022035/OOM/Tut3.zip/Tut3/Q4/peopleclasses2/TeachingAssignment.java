/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package peopleclasses2;

/**
 *
 * @author devam
 */
public class TeachingAssignment {
    //cant do as java doesnt support multiple inheritance, we can use interfaces and abstract classes but that hasnt been covered yet
}
