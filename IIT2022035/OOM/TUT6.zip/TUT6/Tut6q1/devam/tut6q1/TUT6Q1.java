/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package devam.tut6q1;
import Classes.*;
/**
 *
 * @author devam
 */
public class TUT6Q1 {

    public static void main(String[] args) {
        Bank B1=new Bank();
        SavingsAccount S1=new SavingsAccount(71,.08);
        B1.addAccount(S1);
        CurrentAccount C1=new CurrentAccount(72,8000);
        B1.addAccount(C1);
        B1.searchAcc(71).deposit(7000);
        B1.searchAcc(72).deposit(10000);
        SavingsAccount S=(SavingsAccount) B1.searchAcc(71);
        S.addInterest();
        
        B1.searchAcc(71).withdraw(2000);
        B1.searchAcc(71).print();
        B1.searchAcc(72).withdraw(150000);
        B1.searchAcc(72).print();
        B1.searchAcc(72).withdraw(12500);
        B1.searchAcc(72).print();
        
      
    }
}
