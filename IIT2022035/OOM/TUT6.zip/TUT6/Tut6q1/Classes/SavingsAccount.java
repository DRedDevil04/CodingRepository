/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author devam
 */
public class SavingsAccount extends Account {
    private double interest;
    public SavingsAccount(int val,double interest){
        super(val);
        this.interest=interest;
    }
    public void addInterest(){
        deposit(this.getBalance()*(this.interest));
    }
    @Override
    public void withdraw(double sum){
        if (sum<=getBalance()) super.withdraw(sum);
        else System.out.println("Cannot withdraw more than acc balance");
	       
	
    }
    
    
}
