/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;
import java.util.*;
/**
 *
 * @author devam
 */
public class Bank {
    private ArrayList<Account> A=new ArrayList<>();
    public void addAccount(Account a){
        A.add(a);
    }
    public Account searchAcc(double accno){
        for(int i=0;i<A.size();i++){
            if(A.get(i).getAccountNumber()==accno){
                return A.get(i);
            }
        }
        return new Account(0);
    }
}
