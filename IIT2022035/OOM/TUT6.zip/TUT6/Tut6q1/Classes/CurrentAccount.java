/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author devam
 */
public class CurrentAccount extends Account {
    private double overdraftLimit;
    public CurrentAccount(int val,double odl){
        super(val);
        this.overdraftLimit=odl;
    }
    
    @Override
    public void withdraw(double sum){
        if(overdraftLimit+ getBalance()>sum) super.withdraw(sum);
        else System.out.println("Overdraft Limit exceeeded: Cannot withdraw");
    }
    
    
}
