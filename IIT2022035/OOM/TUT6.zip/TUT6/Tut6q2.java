class ABCIceCream{
    void icecream(){
    };
}

class XIceCream extends ABCIceCream{
    void icecream(){
        System.out.println("Vanilla flavoured ice-cream available");
    }
}

class YIceCream extends ABCIceCream{
    void icecream(){
        System.out.println("Vanilla and Chocolate flavoured ice-creams available");
    }
}

public class Tut6q2{
    public static void main(String[] args){
        XIceCream ic1 = new XIceCream();
        ic1.icecream();
        YIceCream ic2 = new YIceCream();
        ic2.icecream();
    }
}